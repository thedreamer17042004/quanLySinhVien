create database SqlSinhvien
go
use SqlSinhvien
go
CREATE TABLE Accounts(
	AccountId VARCHAR(36) PRIMARY KEY,
	UserName VARCHAR(64) NOT NULL,
	Password VARCHAR(256),
	FullName NVARCHAR(100),
	Picture VARCHAR(512),
	Email VARCHAR(64) UNIQUE NOT NULL,
    Gender bit,
    birthday date,
	Address NVARCHAR(256),
	Phone VARCHAR(64),
	Active BIT,
	deleted_at bit 
)
GO
create table Roles(
    RoleId int PRIMARY key identity,
    RoleName varchar(255) not null,
	Active bit,
	deleted_at bit 
)
GO

create table Account_Roles(
    Id int PRIMARY key identity,
    AccountId varchar(36) FOREIGN key references Accounts(AccountId) ON DELETE CASCADE,
    RoleId int references Roles(RoleId) ON DELETE CASCADE
)
GO

-- Bảng Khoa
CREATE TABLE Khoa (
    KhoaID INT PRIMARY KEY IDENTITY(1,1),
    MaKhoa NVARCHAR(10) NOT NULL UNIQUE,
    TenKhoa NVARCHAR(100) NOT NULL
);
GO

-- Bảng Lớp
CREATE TABLE Lop (
    LopID INT PRIMARY KEY IDENTITY(1,1),
    MaLop NVARCHAR(10) NOT NULL UNIQUE,
    TenLop NVARCHAR(100) NOT NULL,
);
GO

-- Bảng SinhVien
CREATE TABLE SinhVien (
    SinhVienID INT PRIMARY KEY IDENTITY(1,1),
    MaSinhVien NVARCHAR(10) NOT NULL UNIQUE,
    HoTen NVARCHAR(100) NOT NULL,
    NgaySinh DATE,
    GioiTinh NVARCHAR(10),
    LopID INT FOREIGN KEY REFERENCES Lop(LopID),
    KhoaID INT FOREIGN KEY REFERENCES Khoa(KhoaID),
    DiaChi NVARCHAR(255),
    Email NVARCHAR(100),
    SoDienThoai NVARCHAR(15)
);
GO

-- Bảng MonHoc (QuanLyMonHoc)
CREATE TABLE MonHoc (
    MonHocID INT PRIMARY KEY IDENTITY(1,1),
    MaMonHoc NVARCHAR(10) NOT NULL UNIQUE,
    TenMonHoc NVARCHAR(100) NOT NULL,
    SoTinChi INT,
    KhoaID INT FOREIGN KEY REFERENCES Khoa(KhoaID),
    MoTa NVARCHAR(255)
);
GO

-- Bảng QuanLyDiem
CREATE TABLE QuanLyDiem (
    DiemID INT PRIMARY KEY IDENTITY(1,1),
    SinhVienID INT FOREIGN KEY REFERENCES SinhVien(SinhVienID),
    MonHocID INT FOREIGN KEY REFERENCES MonHoc(MonHocID),
    Diem FLOAT CHECK (Diem >= 0 AND Diem <= 10)
);
GO

-- Bảng QuanLyDiemDanh
CREATE TABLE QuanLyDiemDanh (
    DiemDanhID INT PRIMARY KEY IDENTITY(1,1),
    SinhVienID INT FOREIGN KEY REFERENCES SinhVien(SinhVienID),
    MonHocID INT FOREIGN KEY REFERENCES MonHoc(MonHocID),
    NgayDiemDanh DATE,
    TrangThai NVARCHAR(20) CHECK (TrangThai IN ('Có mặt', 'Vắng mặt'))
);
GO

-- Bảng QuanLyDiemDanh
CREATE TABLE QuanLyKhoaBieu (
    ID INT PRIMARY KEY IDENTITY(1,1),
    HocKy INT,
    NgayBatDau DATETIME,
    NgayKetThuc DATETIME
);

Go
CREATE TABLE QuanLyKhoaBieu_MonHoc (
    Id int PRIMARY key identity,
    QuanLyKhoaBieuID INT,
    MonHocID INT,
    FOREIGN KEY (QuanLyKhoaBieuID) REFERENCES QuanLyKhoaBieu(ID) ON DELETE CASCADE,
    FOREIGN KEY (MonHocID) REFERENCES MonHoc(MonHocID) ON DELETE CASCADE
);
Go

-- 12345
INSERT INTO Accounts (AccountId, UserName, Password, FullName, Picture, Email)
VALUES 
('1', 'Nam', '$2a$12$jukAsGNTZPD0GRKkse1Gz.sQYQc8awziQFlD.R5fhckJT4ce91q3q', 'ADMIN Nam', '', 'admin@gmail.com', 1, null, null, null, 1, 0),
('2', 'Khôi', '$2a$12$60gUzsoFEIxVjx1PWnq46urTSjHBCUL6kdPvFRTVyNLWwHp7tCuUa', 'User khôi', '', 'khoi@gmail.com', 1, null, null, null, 1, 0),
('3', 'Việt', '$2a$12$HWieS/bs6vwthNUhhdl0/uw8usZp2Tt1C58oQXt.hNvbE//66DsCG', 'Manager Việt', '', 'viet@gmail.com', 1, null, null, null, 1, 0);

go
insert into Roles(RoleName) values ('ROLE_ADMIN'),
('ROLE_USER'),
('ROLE_MANAGER')

go
insert into Account_Roles( AccountId, RoleId) 
values( 1, 1),
( 2, 2),
(3, 3)

go
ALTER TABLE QuanLyDiemDanh
ADD soBuoiVang int;